<?php
// Text
$_['text_home']           = 'Inicio';
$_['text_title']           = 'Mercadolivre Autenticação';
$_['heading_title']           = 'Mercadolivre Autenticação';
$_['text_intro']                      = 'Autenticação da sua conta Mercadolivre com opencart. Basta clicar no link a seguir para começar';
$_['text_auth']                      = 'Autenticar Mercadolivre';
$_['text_auth_done']                      = 'Sua autenticação já foi feita !.';
$_['text_reauth']                      = 'Re-autenticar Mercadolivre';


?>