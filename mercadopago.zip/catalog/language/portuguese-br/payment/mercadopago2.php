<?php
// Text
$_['text_title'] = '<img src="image/mercadopago/mercadopagobr.jpg" alt="MercadoPago - Meios de pagamento" title="MercadoPago - Meios de pagamento" width="125" height="125"/>';
$_['currency_no_support'] = 'A moeda selecionada n�o e aceita pelo Mercadopago';
?>