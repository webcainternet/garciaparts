<?php
// Text
$_['text_title'] = '<img src="image/mercadopago/mercadopagoar.jpg" alt="MercadoPago" title="MercadoPago" width="125" height="125"/>';
$_['currency_no_support'] = 'La moneda seleccionado no es aceptado por MercadoPago';
?>