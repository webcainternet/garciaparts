<?php
// Text
$_['text_title'] = 'MercadoPago';
$_['currency_no_support'] = 'The currency selected is not supported by MercadoPago';
?>